#define TE_AIX5

#include "obj-format.h"
