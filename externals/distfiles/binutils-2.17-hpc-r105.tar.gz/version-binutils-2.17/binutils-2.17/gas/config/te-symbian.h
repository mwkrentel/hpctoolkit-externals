#define TE_SYMBIAN 1

#include "te-armeabi.h"
