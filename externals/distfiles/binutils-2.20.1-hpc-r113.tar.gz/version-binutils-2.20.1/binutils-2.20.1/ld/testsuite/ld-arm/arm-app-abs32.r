
tmpdir/arm-app-abs32:     file format elf32-(little|big)arm

DYNAMIC RELOCATION RECORDS
OFFSET   TYPE              VALUE 
.* R_ARM_JUMP_SLOT   lib_func1


