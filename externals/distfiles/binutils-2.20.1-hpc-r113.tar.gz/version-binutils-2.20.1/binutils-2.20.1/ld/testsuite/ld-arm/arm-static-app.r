
tmpdir/arm-static-app:     file format elf32-(little|big)arm

