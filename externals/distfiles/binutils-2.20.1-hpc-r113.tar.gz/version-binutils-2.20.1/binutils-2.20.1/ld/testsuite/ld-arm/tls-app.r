
.*:     file format elf32-.*arm

DYNAMIC RELOCATION RECORDS
OFFSET   TYPE              VALUE 
[0-9a-f]+ R_ARM_TLS_DTPMOD32  app_gd
[0-9a-f]+ R_ARM_TLS_DTPOFF32  app_gd
[0-9a-f]+ R_ARM_TLS_DTPMOD32  lib_gd
[0-9a-f]+ R_ARM_TLS_DTPOFF32  lib_gd
[0-9a-f]+ R_ARM_TLS_TPOFF32  app_ie
