void
foo ()
{
}

asm (".symver foo,foo@VERS.0");
