/* void f<int [3], char>(int (*) [3], char) */
void _Z1fIA3_icEvPT_T0_() {}

/* void f<double [3], long>(double (*) [3], long) */
void _Z1fIA3_dlEvPT_T0_() {}

