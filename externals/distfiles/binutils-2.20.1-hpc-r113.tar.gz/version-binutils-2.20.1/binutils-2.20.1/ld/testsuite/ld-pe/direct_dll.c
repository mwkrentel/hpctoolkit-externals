__declspec(dllexport) int
dll_func (void)
{
  return 10;
}
