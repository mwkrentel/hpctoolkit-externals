auto foo(int i) -> int {
	return i - 1;
}

int main()
{
	return foo(1);
}
