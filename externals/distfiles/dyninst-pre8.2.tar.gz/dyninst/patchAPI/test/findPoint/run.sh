rm log
./test.exe > log
